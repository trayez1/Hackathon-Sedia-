import { useMemo } from "react";
import { CAMPUS_VIEWBOX, LOCATIONS_BY_ID, PATHS } from "../data/seed.js";
import { getHeatmapData } from "../services/store.js";

const TYPE_ICON = {
  "Entrance": "🚪", "Academic / Library": "📚", "Faculty": "🏛",
  "Auditorium": "🎭", "Administration": "🏢", "Food & Beverage": "🍽",
  "Student Services": "🧑‍🤝‍🧑", "Sports": "🏟", "Residential": "🏠",
  "Health": "⚕", "Parking": "🅿", "Academic": "🏫",
};

export default function CampusMap({
  locations,
  selectedId,
  onSelect,
  routePath,
  obstacleLocationIds = [],
  showHeatmap = false,
  originId = "loc-gate",
}) {
  const paths = PATHS;
  const heat = useMemo(() => (showHeatmap ? getHeatmapData() : []), [showHeatmap]);
  const heatById = useMemo(() => Object.fromEntries(heat.map((h) => [h.id, h.reportCount])), [heat]);

  const routeLocs = routePath ? routePath.map((id) => LOCATIONS_BY_ID[id]).filter(Boolean) : null;
  const routeD = routeLocs && routeLocs.length > 1
    ? "M " + routeLocs.map((l) => `${l.x} ${l.y}`).join(" L ")
    : null;

  return (
    <svg
      viewBox={CAMPUS_VIEWBOX}
      className="w-full h-full"
      role="img"
      aria-label="Interactive map of Multimedia University Cyberjaya campus"
    >
      <rect x="0" y="0" width="1000" height="640" fill="#f2f6f3" />
      {/* stylised greenery */}
      <circle cx="120" cy="150" r="70" fill="#e3f0e6" />
      <circle cx="900" cy="560" r="90" fill="#e3f0e6" />
      <circle cx="900" cy="120" r="60" fill="#e3f0e6" />

      {/* pedestrian paths */}
      {paths.map(([a, b], i) => {
        const la = LOCATIONS_BY_ID[a], lb = LOCATIONS_BY_ID[b];
        if (!la || !lb) return null;
        return (
          <line
            key={i}
            x1={la.x} y1={la.y} x2={lb.x} y2={lb.y}
            stroke="#cfd8d4" strokeWidth="6" strokeLinecap="round"
          />
        );
      })}

      {/* heatmap overlay */}
      {showHeatmap && heat.map((h) => {
        const count = h.reportCount;
        if (!count) return null;
        const r = 22 + Math.min(count, 5) * 10;
        const opacity = Math.min(0.12 + count * 0.08, 0.55);
        return (
          <circle key={h.id} cx={h.x} cy={h.y} r={r} fill="#dc2626" opacity={opacity} />
        );
      })}

      {/* active route */}
      {routeD && (
        <path
          d={routeD}
          fill="none"
          stroke="#106b4b"
          strokeWidth="7"
          strokeDasharray="2 12"
          strokeLinecap="round"
        >
          <animate attributeName="stroke-dashoffset" from="28" to="0" dur="1s" repeatCount="indefinite" />
        </path>
      )}

      {/* location markers */}
      {locations.map((loc) => {
        const isSelected = loc.id === selectedId;
        const isOrigin = loc.id === originId;
        const hasObstacle = obstacleLocationIds.includes(loc.id);
        const icon = isOrigin ? "📍" : (TYPE_ICON[loc.type] || "📌");
        return (
          <g
            key={loc.id}
            transform={`translate(${loc.x} ${loc.y})`}
            className="cursor-pointer focus:outline-none"
            tabIndex={0}
            role="button"
            aria-label={`${loc.name}${hasObstacle ? ", has an active accessibility report" : ""}`}
            onClick={() => onSelect?.(loc)}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") onSelect?.(loc); }}
          >
            {isSelected && <circle r="26" fill="none" stroke="#106b4b" strokeWidth="2" className="pulse-ring" />}
            <circle
              r={isOrigin ? 16 : 14}
              fill={isSelected ? "#106b4b" : "#ffffff"}
              stroke={isSelected ? "#0e4634" : "#94a89d"}
              strokeWidth="2"
            />
            <text textAnchor="middle" dy="5" fontSize="14">{icon}</text>
            {hasObstacle && (
              <circle cx="11" cy="-11" r="6" fill="#dc2626" stroke="#fff" strokeWidth="1.5" />
            )}
            <text
              textAnchor="middle"
              y="30"
              fontSize="11"
              fontWeight={isSelected ? "700" : "500"}
              fill={isSelected ? "#0e4634" : "#334843"}
              className="select-none"
            >
              {loc.name.length > 22 ? loc.name.slice(0, 20) + "…" : loc.name}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
