import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ProfileProvider } from "./context/ProfileContext.jsx";
import NavBar from "./components/NavBar.jsx";
import Landing from "./pages/Landing.jsx";
import Explore from "./pages/Explore.jsx";
import ReportObstacle from "./pages/ReportObstacle.jsx";
import Admin from "./pages/Admin.jsx";

export default function App() {
  return (
    <ProfileProvider>
      <BrowserRouter>
        <div className="min-h-screen flex flex-col">
          <NavBar />
          <main className="flex-1 flex flex-col">
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/explore" element={<Explore />} />
              <Route path="/report" element={<ReportObstacle />} />
              <Route path="/admin" element={<Admin />} />
            </Routes>
          </main>
        </div>
      </BrowserRouter>
    </ProfileProvider>
  );
}
