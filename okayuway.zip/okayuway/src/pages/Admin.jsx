import { useState } from "react";
import { useStoreVersion } from "../services/useStore.js";
import { getReports, getAdminStats, adminSetStatus, getLocationById, getConfidence, getHeatmapData } from "../services/store.js";
import { SeverityBadge, StatusPill } from "../components/Badges.jsx";
import { timeAgo } from "../utils/time.js";

const DEMO_ADMIN = { name: "Aisyah (Accessibility Officer)", email: "admin@mmu.demo" };

export default function Admin() {
  useStoreVersion();
  const [authed, setAuthed] = useState(false);
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  if (!authed) {
    return (
      <div className="flex-1 flex items-center justify-center px-4 py-16">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (form.email === "admin@mmu.demo" && form.password === "demo1234") {
              setAuthed(true);
            } else {
              setError("Invalid demo credentials. See README for the demo login.");
            }
          }}
          className="w-full max-w-sm rounded-2xl bg-white ring-1 ring-ink-900/10 p-6 shadow-sm"
        >
          <h1 className="text-lg font-bold text-ink-900">Administrator sign in</h1>
          <p className="text-sm text-ink-900/60 mt-1 mb-5">Campus facilities & accessibility officers only.</p>
          <label className="block text-sm font-medium mb-1">Email</label>
          <input
            type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm mb-3"
            placeholder="admin@mmu.demo" required
          />
          <label className="block text-sm font-medium mb-1">Password</label>
          <input
            type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm mb-3"
            placeholder="••••••••" required
          />
          {error && <p className="text-xs text-red-600 mb-3" role="alert">{error}</p>}
          <button type="submit" className="focus-ring w-full rounded-xl bg-ink-900 hover:bg-ink-900/90 text-white font-semibold px-4 py-3 text-sm">
            Sign in
          </button>
          <p className="text-xs text-ink-900/40 mt-4 text-center">Demo credentials: admin@mmu.demo / demo1234</p>
        </form>
      </div>
    );
  }

  return <Dashboard onSignOut={() => setAuthed(false)} />;
}

function Dashboard({ onSignOut }) {
  const stats = getAdminStats();
  const reports = getReports();
  const heat = getHeatmapData().filter((h) => h.reportCount > 0).sort((a, b) => b.reportCount - a.reportCount);
  const maxCount = Math.max(1, ...heat.map((h) => h.reportCount));

  return (
    <div className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">Accessibility Admin Dashboard</h1>
          <p className="text-sm text-ink-900/60">Signed in as {DEMO_ADMIN.name}</p>
        </div>
        <button onClick={onSignOut} className="focus-ring rounded-lg ring-1 ring-ink-900/15 px-4 py-2 text-sm font-medium hover:bg-ink-900/5">
          Sign out
        </button>
      </div>

      <div className="grid sm:grid-cols-4 gap-4 mb-8">
        <StatBox label="Active Reports" value={stats.active} tone="brand" />
        <StatBox label="Pending Verification" value={stats.pending} tone="amber" />
        <StatBox label="Resolved Issues" value={stats.resolved} tone="ink" />
        <StatBox label="High Priority" value={stats.highPriority} tone="red" />
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h2 className="text-sm font-semibold text-ink-900/70 mb-3">Reports</h2>
          <div className="rounded-2xl ring-1 ring-ink-900/10 bg-white overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-ink-900/5 text-left text-xs uppercase tracking-wide text-ink-900/50">
                <tr>
                  <th className="px-4 py-3">Issue</th>
                  <th className="px-4 py-3">Location</th>
                  <th className="px-4 py-3">Severity</th>
                  <th className="px-4 py-3">Confidence</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Time</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <ReportTableRow key={r.id} report={r} />
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <h2 className="text-sm font-semibold text-ink-900/70 mb-3">Accessibility heatmap</h2>
          <p className="text-xs text-ink-900/50 mb-3">Locations ranked by number of accessibility reports — helps prioritize infrastructure repairs.</p>
          <div className="rounded-2xl ring-1 ring-ink-900/10 bg-white p-4 space-y-3">
            {heat.length === 0 && <p className="text-sm text-ink-900/40">No reports yet.</p>}
            {heat.map((h) => (
              <div key={h.id}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-ink-900/80">{h.name}</span>
                  <span className="text-ink-900/50 text-xs">{h.reportCount} report{h.reportCount === 1 ? "" : "s"}</span>
                </div>
                <div className="h-2 rounded-full bg-ink-900/5 overflow-hidden">
                  <div className="h-full bg-red-500 rounded-full" style={{ width: `${(h.reportCount / maxCount) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, tone }) {
  const toneMap = { brand: "text-brand-700 bg-brand-50", amber: "text-amber-700 bg-amber-50", red: "text-red-700 bg-red-50", ink: "text-ink-900 bg-ink-900/5" };
  return (
    <div className={`rounded-2xl ${toneMap[tone]} p-5`}>
      <div className="text-3xl font-bold">{value}</div>
      <div className="text-sm mt-1 opacity-80">{label}</div>
    </div>
  );
}

function ReportTableRow({ report }) {
  const loc = getLocationById(report.locationId);
  const confidence = getConfidence(report);
  return (
    <tr className="border-t border-ink-900/5">
      <td className="px-4 py-3 font-medium text-ink-900">{report.type}</td>
      <td className="px-4 py-3 text-ink-900/70">{loc?.name || "—"}</td>
      <td className="px-4 py-3"><SeverityBadge severity={report.severity} /></td>
      <td className="px-4 py-3 text-ink-900/70">{confidence}%</td>
      <td className="px-4 py-3"><StatusPill status={report.status} /></td>
      <td className="px-4 py-3 text-ink-900/50 text-xs">{timeAgo(report.createdAt)}</td>
      <td className="px-4 py-3">
        <div className="flex gap-1.5 flex-wrap">
          {report.status !== "verified" && report.status !== "resolved" && (
            <button onClick={() => adminSetStatus(report.id, "verified")} className="focus-ring rounded-lg bg-brand-50 hover:bg-brand-100 text-brand-700 text-xs font-semibold px-2.5 py-1 ring-1 ring-brand-200">
              Verify
            </button>
          )}
          {report.status !== "rejected" && report.status !== "resolved" && (
            <button onClick={() => adminSetStatus(report.id, "rejected")} className="focus-ring rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold px-2.5 py-1 ring-1 ring-red-200">
              Reject
            </button>
          )}
          {report.status !== "resolved" && (
            <button onClick={() => adminSetStatus(report.id, "resolved")} className="focus-ring rounded-lg bg-ink-900/5 hover:bg-ink-900/10 text-ink-900/70 text-xs font-semibold px-2.5 py-1 ring-1 ring-ink-900/10">
              Mark resolved
            </button>
          )}
        </div>
      </td>
    </tr>
  );
}
