// ============================================================================
// okayUway mock backend.
//
// This module simulates: REST API + PostgreSQL database + routing engine.
// Every exported function is written the way an API client (e.g. a fetch()
// wrapper) would be, so swapping this file for real network calls later
// requires no changes to components. State is kept in memory and mirrored to
// localStorage so a hackathon demo survives page refreshes.
// ============================================================================
import {
  LOCATIONS, LOCATIONS_BY_ID, PATHS, INITIAL_FEATURES, ROUTE_TEMPLATES,
  INITIAL_REPORTS, minutesAgo,
} from "../data/seed.js";

const STORAGE_KEY = "okayuway_state_v1";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.features && parsed.reports) return parsed;
    }
  } catch (e) { /* ignore corrupted storage */ }
  return {
    features: structuredClone(INITIAL_FEATURES),
    reports: structuredClone(INITIAL_REPORTS),
  };
}

let state = loadState();
const listeners = new Set();

function persist() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) { /* quota etc */ }
}

function emit() {
  persist();
  listeners.forEach((cb) => cb());
}

export function subscribe(cb) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

// ---------------------------------------------------------------------------
// Locations
// ---------------------------------------------------------------------------
export function getLocations() { return LOCATIONS; }
export function getPaths() { return PATHS; }
export function getLocationById(id) { return LOCATIONS_BY_ID[id] || null; }

export function searchLocations(query) {
  const q = query.trim().toLowerCase();
  if (!q) return LOCATIONS;
  return LOCATIONS.filter(
    (l) => l.name.toLowerCase().includes(q) || l.type.toLowerCase().includes(q)
  );
}

// ---------------------------------------------------------------------------
// Features
// ---------------------------------------------------------------------------
export function getFeatureById(id) { return state.features.find((f) => f.id === id); }
export function getFeaturesForLocation(locationId) {
  return state.features.filter((f) => f.locationId === locationId);
}
export function getAllFeatures() { return state.features; }

// ---------------------------------------------------------------------------
// Scoring engine
//
// score = 100 - sum(penalties), clamped to [0, 100]
// Concept mirrors the brief in section 11: distance is a soft factor (longer
// accessible detours are expected), while stairs / broken lifts / blocked
// ramps / bad pavement / stale data are hard penalties.
// ---------------------------------------------------------------------------
const STATUS_PENALTY = {
  ramp:     { good: 0, steep: 18, blocked: 45, damaged: 30, unknown: 10 },
  lift:     { working: 0, broken: 45, unknown: 12 },
  entrance: { good: 0, damaged: 25, blocked: 45, unknown: 10 },
  stairs:   { good: 20 }, // presence of a stairs-only checkpoint is itself a penalty
  pavement: { good: 0, damaged: 18, blocked: 40, unknown: 8 },
  parking:  { good: 0, damaged: 10, blocked: 25, unknown: 5 },
};

function freshnessPenalty(iso) {
  const hours = (Date.now() - new Date(iso).getTime()) / 36e5;
  if (hours <= 6) return 0;
  if (hours <= 24) return 2;
  if (hours <= 24 * 7) return 6;
  return 12; // stale data penalty
}

export function scoreRoute(routeDef) {
  const featureSnapshots = routeDef.checkpoints.map((fid) => getFeatureById(fid)).filter(Boolean);
  let penalty = 0;
  const issues = [];
  const goods = [];

  featureSnapshots.forEach((f) => {
    const table = STATUS_PENALTY[f.type] || {};
    const p = table[f.status] ?? 8;
    penalty += p;
    if (p > 0) {
      issues.push({ feature: f, penalty: p });
    } else {
      goods.push(f);
    }
    penalty += freshnessPenalty(f.lastVerified);
  });

  // mild distance penalty, capped, so it never dominates a genuinely
  // accessible-but-longer route
  const distancePenalty = Math.min(8, Math.round(routeDef.distance / 200));
  penalty += distancePenalty;

  const score = Math.max(0, Math.min(100, Math.round(100 - penalty)));
  const oldestVerification = featureSnapshots.reduce((oldest, f) => {
    const t = new Date(f.lastVerified).getTime();
    return oldest === null || t < oldest ? t : oldest;
  }, null);

  return {
    score,
    issues,
    goods,
    featureSnapshots,
    oldestVerification: oldestVerification ? new Date(oldestVerification).toISOString() : null,
  };
}

export function getRoutesForDestination(destinationId) {
  const template = ROUTE_TEMPLATES[destinationId];
  if (!template) return null;
  const build = (key, label) => {
    const def = template[key];
    const scored = scoreRoute(def);
    return {
      key,
      label,
      distance: def.distance,
      duration: def.duration,
      path: def.path,
      notes: def.notes || [],
      ...scored,
    };
  };
  const fastest = build("fastest", "Fastest route");
  const accessible = build("accessible", "Recommended accessible route");
  const recommend = accessible.score >= fastest.score ? "accessible" : "fastest";
  return { fastest, accessible, recommend };
}

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------
export function getReports() { return state.reports; }
export function getReportsForLocation(locationId) {
  return state.reports.filter((r) => r.locationId === locationId);
}

let reportCounter = state.reports.length + 1;

export function submitReport({ locationId, featureId, type, description, photoDataUrl, aiAnalysis }) {
  const severity = aiAnalysis?.impact || (type.toLowerCase().includes("lift") || type.toLowerCase().includes("ramp") ? "HIGH" : "MEDIUM");
  const report = {
    id: `rep-${Date.now()}-${reportCounter++}`,
    locationId,
    featureId: featureId || null,
    type,
    description,
    photoDataUrl: photoDataUrl || null,
    severity,
    status: "pending",
    createdAt: new Date().toISOString(),
    confirmations: 1,
    disputes: 0,
    aiAnalysis: aiAnalysis || null,
  };
  state.reports = [report, ...state.reports];
  emit();
  return report;
}

export function confirmReport(reportId) {
  state.reports = state.reports.map((r) =>
    r.id === reportId ? { ...r, confirmations: r.confirmations + 1 } : r
  );
  maybeAutoEscalate(reportId);
  emit();
}

export function disputeReport(reportId) {
  state.reports = state.reports.map((r) =>
    r.id === reportId ? { ...r, disputes: r.disputes + 1 } : r
  );
  emit();
}

function maybeAutoEscalate(reportId) {
  const r = state.reports.find((x) => x.id === reportId);
  if (r && r.status === "pending" && r.confirmations >= 5) {
    applyVerification(reportId, "verified");
  }
}

// Admin actions — updates report status AND, when verifying, pushes the
// obstruction down into the linked AccessibilityFeature so routes
// recalculate live.
export function adminSetStatus(reportId, status) {
  applyVerification(reportId, status);
  emit();
}

function applyVerification(reportId, status) {
  const report = state.reports.find((r) => r.id === reportId);
  if (!report) return;
  report.status = status;

  if (status === "verified" && report.featureId) {
    const feature = state.features.find((f) => f.id === report.featureId);
    if (feature) {
      feature.status = inferBadStatusForType(feature.type, report.type);
      feature.lastVerified = new Date().toISOString();
      feature.confirmations = report.confirmations;
      feature.disputes = report.disputes;
      feature.description = report.description;
    }
  }
  if (status === "resolved" && report.featureId) {
    const feature = state.features.find((f) => f.id === report.featureId);
    if (feature) {
      feature.status = feature.type === "lift" ? "working" : "good";
      feature.lastVerified = new Date().toISOString();
    }
  }
}

function inferBadStatusForType(featureType, reportType) {
  const t = reportType.toLowerCase();
  if (featureType === "lift") return "broken";
  if (featureType === "ramp") {
    if (t.includes("steep") || t.includes("slope")) return "steep";
    return "blocked";
  }
  if (featureType === "entrance") return t.includes("closed") ? "blocked" : "damaged";
  if (featureType === "pavement") return t.includes("construction") ? "blocked" : "damaged";
  return "damaged";
}

export function getConfidence(report) {
  const total = report.confirmations + report.disputes;
  if (total === 0) return 50;
  return Math.round((report.confirmations / total) * 100);
}

// ---------------------------------------------------------------------------
// AI analysis abstraction.
//
// IMPORTANT: This is a controlled, deterministic DEMO response, not a real
// computer-vision model. It is isolated behind this single function so a
// real CV/LLM API call can be dropped in later without touching UI code.
// ---------------------------------------------------------------------------
export async function runAIAnalysis({ obstacleType, hasPhoto }) {
  await new Promise((res) => setTimeout(res, 1400)); // simulate inference latency

  const type = (obstacleType || "").toLowerCase();
  const rampRelated = type.includes("ramp");
  const liftRelated = type.includes("lift");
  const object = rampRelated
    ? "Motorcycle / parked vehicle"
    : liftRelated
    ? "Out-of-service signage"
    : "Obstruction";

  const impact = rampRelated || liftRelated ? "HIGH" : type.includes("pavement") ? "MEDIUM" : "MEDIUM";

  return {
    simulated: true,
    rampDetected: rampRelated && hasPhoto,
    obstructionDetected: hasPhoto,
    object: hasPhoto ? object : null,
    impact,
    recommendation: hasPhoto
      ? `Temporarily mark this ${rampRelated ? "entrance/ramp" : "feature"} as obstructed until verified by an administrator.`
      : "No photo provided — recommendation based on report type only.",
  };
}

// ---------------------------------------------------------------------------
// Admin dashboard aggregates
// ---------------------------------------------------------------------------
export function getAdminStats() {
  const reports = state.reports;
  return {
    active: reports.filter((r) => r.status !== "resolved").length,
    pending: reports.filter((r) => r.status === "pending").length,
    resolved: reports.filter((r) => r.status === "resolved").length,
    highPriority: reports.filter((r) => r.severity === "HIGH" && r.status !== "resolved").length,
  };
}

// Heatmap: aggregate report counts per location -> "problem intensity"
export function getHeatmapData() {
  const counts = {};
  state.reports.forEach((r) => {
    counts[r.locationId] = (counts[r.locationId] || 0) + 1;
  });
  return LOCATIONS.map((l) => ({
    ...l,
    reportCount: counts[l.id] || 0,
  }));
}

export function resetDemoData() {
  state = {
    features: structuredClone(INITIAL_FEATURES),
    reports: structuredClone(INITIAL_REPORTS),
  };
  emit();
}
