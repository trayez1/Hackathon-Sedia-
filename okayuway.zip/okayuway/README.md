# okayUway

**"Normal maps tell you how to get there. okayUway tells you whether you can actually get there."**

Accessibility-aware navigation for wheelchair users and people with mobility impairments.
Pilot area: **Multimedia University (MMU), Cyberjaya** (demo data only).

## What was built

A working single-page app (not a mockup) implementing the FIND → VERIFY → ROUTE → REPORT → UPDATE loop:

- Landing page with the product pitch and demo stats
- Interactive SVG map of MMU Cyberjaya (15 locations, pedestrian paths)
- Accessibility profile selector (Wheelchair / Mobility impairment; Visual impairment shown as "coming soon")
- Destination search, scoped strictly to the MMU pilot dataset, with an explicit
  "outside pilot area" message for anything else (no fabricated data)
- Accessibility-aware route scoring engine (not shortest-path): every route is scored from
  live feature state — stairs, ramp condition, lift status, pavement condition, entrance
  accessibility, and data freshness — see `src/services/store.js: scoreRoute()`
- Side-by-side Fastest vs. Recommended Accessible route comparison, with the app recommending
  the accessible route even when longer
- Live "Accessibility Warning" banner + "Show alternative route" when the active route crosses
  a broken/blocked feature
- Report an Obstacle flow: type, location, description, **photo upload**, and a **simulated AI
  image analysis step** (clearly labeled as simulated — see below)
- Community verification: Confirm / Dispute buttons, confidence %, "conflicting reports" state,
  auto-escalation to "verified" after 5 confirmations
- Live map + route recalculation: verifying a report immediately downgrades the linked
  accessibility feature, which changes the score of any route depending on it
- Admin dashboard (demo login) with stats, a sortable report table (Verify / Reject / Resolve),
  and an accessibility heatmap ranking locations by report volume
- Accessibility of the app itself: keyboard navigation, focus rings, ARIA labels on the map and
  progress bars, text alongside every icon, no color-only signaling, large touch targets

## Architecture

```
Frontend (React + Vite + Tailwind v4)
        ↓
Mock backend / API layer  (src/services/store.js)
        ↓
"Database"  (src/data/seed.js  — shaped like the real schema, see below)
        ↓
AI abstraction  (src/services/store.js: runAIAnalysis — swappable for a real CV/LLM API)
        ↓
Map  (src/components/CampusMap.jsx — SVG, swappable for Mapbox/OSM)
```

`src/services/store.js` is written as an API client would be (`getLocations()`,
`submitReport()`, `adminSetStatus()`, etc.), with an in-memory + localStorage-backed store
standing in for PostgreSQL/Supabase and a pub-sub `subscribe()` so React components re-render
on change. This means swapping in a real backend later means rewriting this one file, not the UI.

Data shapes mirror the schema in the brief: `Users` (implicit/anonymous in this demo),
`Locations`, `AccessibilityFeatures`, `Reports`, `Verifications` (confirm/dispute counters),
`Routes` (computed, not stored — see `getRoutesForDestination`).

## Completed features (checklist)

- [x] MMU Cyberjaya map (Priority 1)
- [x] Destination search, scoped to pilot + outside-pilot protection (Priority 2)
- [x] Wheelchair accessibility profile (Priority 3)
- [x] Accessibility-aware route scoring, not shortest-path (Priority 4)
- [x] Accessibility score with visual bar + plain-language caveat (Priority 5)
- [x] Report obstacle flow (Priority 6)
- [x] Photo upload with client-side validation (Priority 7)
- [x] AI analysis abstraction, clearly labeled as simulated (Priority 8)
- [x] Community verification (confirm/dispute, confidence, conflicting reports) (Priority 9)
- [x] Admin dashboard with demo login, report table, actions (Priority 10)
- [x] Accessibility heatmap (Priority 11)
- [x] UI polish pass (Priority 12)
- [ ] Visual-impairment profile — UI stub only, not implemented (explicitly out of scope for MVP)
- [ ] Real backend / DB / auth — mocked, by design, for the hackathon

## How to run

```bash
cd okayuway
npm install
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`).

To build a production bundle:

```bash
npm run build
npm run preview
```

## Environment variables

None are required to run the demo — everything (map, AI analysis, "database") is self-contained
in the frontend for the hackathon build. If you connect this to a real backend later:

```
VITE_API_BASE_URL=       # your REST/GraphQL API
VITE_MAPBOX_TOKEN=       # if replacing the SVG map with Mapbox
VITE_CV_API_KEY=         # a real computer-vision provider for obstacle photo analysis
```

Never commit real API keys — use a local `.env` file (already covered by the default `.gitignore`).

## Demo credentials

Admin dashboard (`/admin`) — local demo login only, not a real auth system:

```
Email:    admin@mmu.demo
Password: demo1234
```

## Hackathon demo script (2–3 minutes)

1. **Open** okayUway on the landing page — read the tagline, click **Explore MMU**.
2. **Select** the Wheelchair profile (selected by default).
3. **Search** "Library" and select **MMU Library**.
4. **Show routes**: point out Fastest (400m, 5 min, low score, stairs) vs. **Recommended
   Accessible Route** (650m, 8 min, high score, step-free) — note the app recommends the
   longer route.
5. **The wow moment**: open **Report an Obstacle**, select **Faculty of Engineering (FOE)**,
   pick **Blocked ramp**, upload any photo, click **Run AI accessibility analysis** — show the
   simulated AI detecting an obstruction with HIGH impact — submit.
6. **Live update**: go back to **Explore**, select **FOE** — the accessible route to FOE now
   shows a lower score / warning banner because the ramp feature is scored live.
7. **Admin view**: open **Admin** (demo login above), show the new report in the table with
   AI-assisted severity, click **Verify** — status flips to Verified and feeds back into the map.
8. Close on the heatmap: "this turns okayUway into a data-driven accessibility management tool
   for the university, not just a map for one student."

## Known limitations

- All accessibility data is **demo data** for a hackathon pilot — it is not verified, official
  MMU accessibility information, and should not be used for real navigation decisions.
- Routing is based on precomputed route templates between the Main Gate and each destination
  (with live re-scoring from feature state), not a full pathfinding/graph-search engine.
- The AI image analysis is a deterministic, clearly-labeled simulation, not a real computer
  vision model — see `runAIAnalysis()` in `src/services/store.js`.
- Data persists only in the browser's localStorage on one device; there is no real multi-user
  sync, authentication, or server-side database.
- Visual-impairment support is a UI placeholder, not implemented.

## Future improvements

- Connect `runAIAnalysis` to a real CV/LLM API for genuine obstacle detection
- Replace the stylized SVG map with Mapbox/OSM + real GPS coordinates
- Real backend (Postgres/Supabase) + auth, replacing `src/services/store.js`
- Full graph-based routing across arbitrary origin/destination pairs
- Expand beyond the MMU pilot: other universities → Cyberjaya → Kuala Lumpur → Malaysia → ASEAN
