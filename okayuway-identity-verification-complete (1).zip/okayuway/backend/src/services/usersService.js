import { db } from "../db/index.js";
import { resolveVerificationDocument, deleteVerificationDocument } from "./secureDocumentStorage.js";

const RETENTION_DAYS = Number(process.env.VERIFICATION_DOCUMENT_RETENTION_DAYS || 30);

// Public-safe projection: never includes password_hash or the raw
// selfie_path/id_document_path filenames (those are only ever handed to
// the streaming route in routes/admin.js after its own admin auth check).
function rowToPublicUser(row) {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone,
    verificationStatus: row.verification_status,
    verificationSubmittedAt: row.verification_submitted_at,
    verifiedAt: row.verified_at,
    verifiedBy: row.verified_by,
    rejectedAt: row.rejected_at,
    rejectedBy: row.rejected_by,
  };
}

// Admin list/detail projection: adds hasSelfie/hasIdDocument flags so the
// dashboard knows whether to show "view document" links, without ever
// including the document bytes or even the filenames themselves.
function rowToAdminUser(row) {
  return {
    ...rowToPublicUser(row),
    hasSelfie: !!row.selfie_path,
    hasIdDocument: !!row.id_document_path,
  };
}

export function getUserById(id) {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id) || null;
}

export function getPublicUserById(id) {
  const row = getUserById(id);
  return row ? rowToPublicUser(row) : null;
}

export function getPendingUsers() {
  return db
    .prepare("SELECT * FROM users WHERE verification_status = 'pending' ORDER BY verification_submitted_at ASC")
    .all()
    .map(rowToAdminUser);
}

export function getAdminUserDetail(id) {
  const row = getUserById(id);
  return row ? rowToAdminUser(row) : null;
}

// Only ever called from the admin document-streaming route, after
// requireAdmin has already run.
export function getVerificationDocumentPath(userId, kind) {
  const row = getUserById(userId);
  if (!row) return null;
  const filename = kind === "selfie" ? row.selfie_path : kind === "id" ? row.id_document_path : null;
  return resolveVerificationDocument(filename);
}

export function approveVerification(userId, adminName) {
  const row = getUserById(userId);
  if (!row) return null;
  db.prepare(
    `UPDATE users SET verification_status = 'verified', verified_at = ?, verified_by = ?,
       rejected_at = NULL, rejected_by = NULL WHERE id = ?`
  ).run(new Date().toISOString(), adminName, userId);
  return getAdminUserDetail(userId);
}

export function rejectVerification(userId, adminName) {
  const row = getUserById(userId);
  if (!row) return null;
  db.prepare(
    `UPDATE users SET verification_status = 'rejected', rejected_at = ?, rejected_by = ?
       WHERE id = ?`
  ).run(new Date().toISOString(), adminName, userId);
  return getAdminUserDetail(userId);
}

// Data-minimization / retention (spec section 19): deletes the selfie + ID
// document files (not the account itself) for users whose verification
// was decided more than RETENTION_DAYS ago, and clears the stored
// filenames so the DB no longer references them. There is no scheduler
// wired up in this repo — this is invoked by the admin-only
// POST /api/admin/verification/cleanup route, and a production deployment
// should call that on a cron instead of relying on an admin to click it.
export function purgeExpiredVerificationDocuments() {
  const cutoff = new Date(Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000).toISOString();
  const candidates = db
    .prepare(
      `SELECT id, selfie_path, id_document_path FROM users
       WHERE (selfie_path IS NOT NULL OR id_document_path IS NOT NULL)
         AND (
           (verification_status = 'rejected' AND rejected_at IS NOT NULL AND rejected_at < ?)
           OR (verification_status = 'verified' AND verified_at IS NOT NULL AND verified_at < ?)
         )`
    )
    .all(cutoff, cutoff);

  const clearStmt = db.prepare(
    `UPDATE users SET selfie_path = NULL, id_document_path = NULL WHERE id = ?`
  );
  for (const row of candidates) {
    deleteVerificationDocument(row.selfie_path);
    deleteVerificationDocument(row.id_document_path);
    clearStmt.run(row.id);
  }
  return candidates.length;
}
