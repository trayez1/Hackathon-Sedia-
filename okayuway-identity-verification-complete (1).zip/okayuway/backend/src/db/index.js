import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  LOCATIONS, LOCATION_ALIASES, PATHS, ROUTE_TEMPLATES,
  buildInitialFeatures, buildInitialReports,
} from "./seed-data.js";
import { deleteVerificationDocument } from "../services/secureDocumentStorage.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const DB_PATH = process.env.DB_PATH || "./data/okayuway.sqlite";
fs.mkdirSync(path.dirname(path.resolve(DB_PATH)), { recursive: true });

export const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
db.exec(schema);

// CREATE TABLE IF NOT EXISTS only helps on a brand-new database file — an
// existing okayuway.sqlite from before the identity-verification feature
// won't pick up the new users/reports columns from schema.sql alone.
// Add anything that's missing, idempotently, on every boot.
function ensureColumn(table, column, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  if (!cols.includes(column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}

function runMigrations() {
  ensureColumn("users", "phone", "phone TEXT");
  ensureColumn("users", "verification_status", "verification_status TEXT NOT NULL DEFAULT 'pending'");
  ensureColumn("users", "selfie_path", "selfie_path TEXT");
  ensureColumn("users", "id_document_path", "id_document_path TEXT");
  ensureColumn("users", "consent_given", "consent_given INTEGER NOT NULL DEFAULT 0");
  ensureColumn("users", "consent_at", "consent_at TEXT");
  ensureColumn("users", "verification_submitted_at", "verification_submitted_at TEXT");
  ensureColumn("users", "verified_at", "verified_at TEXT");
  ensureColumn("users", "verified_by", "verified_by TEXT");
  ensureColumn("users", "rejected_at", "rejected_at TEXT");
  ensureColumn("users", "rejected_by", "rejected_by TEXT");
  ensureColumn("reports", "user_id", "user_id INTEGER REFERENCES users(id) ON DELETE SET NULL");
  db.exec(`CREATE INDEX IF NOT EXISTS idx_reports_user ON reports(user_id)`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_users_verification_status ON users(verification_status)`);

  // Accounts created before this feature existed have no verification
  // documents on file. Treat them as already "verified" instead of
  // silently locking out every pre-existing account — an admin can still
  // reject them later if that's wrong for a given deployment.
  db.exec(`UPDATE users SET verification_status = 'verified'
           WHERE verification_status = 'pending' AND selfie_path IS NULL AND id_document_path IS NULL
             AND created_at < datetime('now', '-1 minute')`);
}

runMigrations();

function isEmpty() {
  return db.prepare("SELECT COUNT(*) AS n FROM locations").get().n === 0;
}

function seedDatabase() {
  const insertLocation = db.prepare(
    `INSERT INTO locations (id, name, type, x, y, description, landmark)
     VALUES (@id, @name, @type, @x, @y, @description, @landmark)`
  );
  const insertAlias = db.prepare(
    `INSERT INTO location_aliases (location_id, alias) VALUES (?, ?)`
  );
  const insertPath = db.prepare(
    `INSERT OR IGNORE INTO paths (location_a, location_b) VALUES (?, ?)`
  );
  const insertFeature = db.prepare(
    `INSERT INTO features (id, location_id, type, name, status, last_verified, confirmations, disputes, description)
     VALUES (@id, @locationId, @type, @name, @status, @lastVerified, @confirmations, @disputes, @description)`
  );
  const insertRouteTemplate = db.prepare(
    `INSERT INTO route_templates (destination_id, route_key, distance, duration, path_json, checkpoints_json, notes_json)
     VALUES (@destinationId, @routeKey, @distance, @duration, @pathJson, @checkpointsJson, @notesJson)`
  );
  const insertReport = db.prepare(
    `INSERT INTO reports (id, location_id, feature_id, type, description, photo_url, severity, status, created_at, confirmations, disputes, ai_analysis_json)
     VALUES (@id, @locationId, @featureId, @type, @description, @photoUrl, @severity, @status, @createdAt, @confirmations, @disputes, @aiAnalysisJson)`
  );
  const insertAdmin = db.prepare(
    `INSERT INTO admin_users (name, email, password_hash) VALUES (?, ?, ?)`
  );

  const seedTx = db.transaction(() => {
    for (const loc of LOCATIONS) {
      insertLocation.run({ description: null, landmark: 0, ...loc, landmark: loc.landmark ? 1 : 0 });
      for (const alias of LOCATION_ALIASES[loc.id] || []) insertAlias.run(loc.id, alias);
    }
    for (const [a, b] of PATHS) insertPath.run(a, b);

    for (const f of buildInitialFeatures()) {
      insertFeature.run({ description: null, ...f });
    }

    for (const [destinationId, byKey] of Object.entries(ROUTE_TEMPLATES)) {
      for (const routeKey of ["fastest", "accessible"]) {
        const def = byKey[routeKey];
        insertRouteTemplate.run({
          destinationId,
          routeKey,
          distance: def.distance,
          duration: def.duration,
          pathJson: JSON.stringify(def.path),
          checkpointsJson: JSON.stringify(def.checkpoints),
          notesJson: JSON.stringify(def.notes || []),
        });
      }
    }

    for (const r of buildInitialReports()) {
      insertReport.run({
        id: r.id,
        locationId: r.locationId,
        featureId: r.featureId || null,
        type: r.type,
        description: r.description,
        photoUrl: r.photoUrl || null,
        severity: r.severity,
        status: r.status,
        createdAt: r.createdAt,
        confirmations: r.confirmations,
        disputes: r.disputes,
        aiAnalysisJson: r.aiAnalysis ? JSON.stringify(r.aiAnalysis) : null,
      });
    }

    // Two seed admin accounts (Adib and Aniq). Each can be overridden via
    // env vars; falls back to sensible demo defaults otherwise.
    const admin1Name = process.env.ADMIN1_NAME || "Adib (Accessibility Officer)";
    const admin1Email = process.env.ADMIN1_EMAIL || "adib@mmu.demo";
    const admin1Password = process.env.ADMIN1_PASSWORD || "demo1234";
    insertAdmin.run(admin1Name, admin1Email, bcrypt.hashSync(admin1Password, 10));

    const admin2Name = process.env.ADMIN2_NAME || "Aniq (Accessibility Officer)";
    const admin2Email = process.env.ADMIN2_EMAIL || "aniq@mmu.demo";
    const admin2Password = process.env.ADMIN2_PASSWORD || "demo1234";
    insertAdmin.run(admin2Name, admin2Email, bcrypt.hashSync(admin2Password, 10));
  });

  seedTx();
}

if (isEmpty()) {
  seedDatabase();
  console.log(`[db] Seeded fresh database at ${path.resolve(DB_PATH)}`);
} else {
  console.log(`[db] Using existing database at ${path.resolve(DB_PATH)}`);
}

// Exposed for the admin "reset demo data" endpoint.
export function resetToSeed() {
  // Wiping the users table would otherwise orphan any selfie/ID document
  // files on disk (they live outside the DB, see secureDocumentStorage.js)
  // — delete those first so a reset doesn't quietly leak identity photos
  // that no longer have an owning account.
  const orphanedDocs = db
    .prepare(`SELECT selfie_path, id_document_path FROM users WHERE selfie_path IS NOT NULL OR id_document_path IS NOT NULL`)
    .all();

  const resetTx = db.transaction(() => {
    db.exec(`DELETE FROM reports; DELETE FROM features; DELETE FROM route_templates;
              DELETE FROM location_aliases; DELETE FROM paths; DELETE FROM locations;
              DELETE FROM admin_users; DELETE FROM users;`);
  });
  resetTx();

  for (const row of orphanedDocs) {
    deleteVerificationDocument(row.selfie_path);
    deleteVerificationDocument(row.id_document_path);
  }

  seedDatabase();
}
