-- okayUway database schema.
-- Mirrors the shapes documented in the frontend README: Locations,
-- AccessibilityFeatures, Reports, Verifications (folded into reports as
-- confirmations/disputes counters), plus route templates and admin users.

CREATE TABLE IF NOT EXISTS locations (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL,
  x           REAL NOT NULL,
  y           REAL NOT NULL,
  description TEXT,
  landmark    INTEGER NOT NULL DEFAULT 0
);

-- Pedestrian path edges between locations (for the campus graph + map lines).
CREATE TABLE IF NOT EXISTS paths (
  location_a TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  location_b TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  PRIMARY KEY (location_a, location_b)
);

-- Location name aliases used by search (e.g. "fci" -> Faculty of Computing).
CREATE TABLE IF NOT EXISTS location_aliases (
  location_id TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  alias       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS features (
  id            TEXT PRIMARY KEY,
  location_id   TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  type          TEXT NOT NULL, -- ramp | lift | entrance | stairs | pavement | parking
  name          TEXT NOT NULL,
  status        TEXT NOT NULL, -- good|working|broken|blocked|damaged|steep|unknown
  last_verified TEXT NOT NULL,
  confirmations INTEGER NOT NULL DEFAULT 0,
  disputes      INTEGER NOT NULL DEFAULT 0,
  description   TEXT
);

-- Hand-curated fastest/accessible route templates FROM the Main Gate to each
-- destination, preserved for flavor-text notes. Any other origin is routed
-- dynamically at request time over `paths` (see services/routingEngine.js).
CREATE TABLE IF NOT EXISTS route_templates (
  destination_id TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  route_key      TEXT NOT NULL CHECK (route_key IN ('fastest', 'accessible')),
  distance       INTEGER NOT NULL,
  duration       INTEGER NOT NULL,
  path_json      TEXT NOT NULL,           -- JSON array of location ids
  checkpoints_json TEXT NOT NULL,         -- JSON array of feature ids
  notes_json     TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (destination_id, route_key)
);

CREATE TABLE IF NOT EXISTS admin_users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL
);

-- Regular (non-admin) student/staff accounts used by the public-facing
-- login. Mirrors admin_users but carries its own table + JWT role so a user
-- token can never be swapped in for admin_users' requireAdmin checks.
--
-- Identity-verification fields (selfie + ID document) support section
-- 13-19 of the registration/verification spec: verification_status starts
-- "pending" on every new account and only moves to "verified"/"rejected"
-- via the admin-only endpoints in routes/admin.js — it is never set from a
-- client-supplied value. selfie_path/id_document_path store only a
-- filename (see services/secureDocumentStorage.js); the files themselves
-- live outside any statically-served directory and are never returned in
-- a normal API response.
CREATE TABLE IF NOT EXISTS users (
  id                        INTEGER PRIMARY KEY AUTOINCREMENT,
  name                      TEXT NOT NULL,
  email                     TEXT NOT NULL UNIQUE,
  phone                     TEXT,
  password_hash             TEXT NOT NULL,
  verification_status       TEXT NOT NULL DEFAULT 'pending', -- pending|verified|rejected
  selfie_path               TEXT,
  id_document_path          TEXT,
  consent_given             INTEGER NOT NULL DEFAULT 0,
  consent_at                TEXT,
  verification_submitted_at TEXT,
  verified_at               TEXT,
  verified_by               TEXT, -- display name of the admin who approved, e.g. "Adib"
  rejected_at                TEXT,
  rejected_by                TEXT,
  created_at                TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reports (
  id            TEXT PRIMARY KEY,
  location_id   TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  feature_id    TEXT REFERENCES features(id) ON DELETE SET NULL,
  user_id       INTEGER REFERENCES users(id) ON DELETE SET NULL, -- reporting account; server-derived from the auth token, never from client input
  type          TEXT NOT NULL,
  description   TEXT NOT NULL,
  photo_url     TEXT,
  severity      TEXT NOT NULL DEFAULT 'MEDIUM',
  status        TEXT NOT NULL DEFAULT 'pending', -- pending|reviewing|verified|rejected|resolved
  created_at    TEXT NOT NULL,
  confirmations INTEGER NOT NULL DEFAULT 1,
  disputes      INTEGER NOT NULL DEFAULT 0,
  ai_analysis_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_features_location ON features(location_id);
CREATE INDEX IF NOT EXISTS idx_reports_location ON reports(location_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_user ON reports(user_id);
CREATE INDEX IF NOT EXISTS idx_users_verification_status ON users(verification_status);
