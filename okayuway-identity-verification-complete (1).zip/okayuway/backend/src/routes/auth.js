import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "../db/index.js";
import { requireUser } from "../middleware/auth.js";
import { saveVerificationDocument, deleteVerificationDocument } from "../services/secureDocumentStorage.js";
import { getPublicUserById } from "../services/usersService.js";

const router = Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Accepts an optional leading "+", spaces, hyphens/parens, 7-20 chars —
// loose on purpose (this is a demo, not a carrier-validated E.164 check)
// but rejects obviously-empty or non-numeric input.
const PHONE_RE = /^\+?[0-9 \-()]{7,20}$/;

function signUserToken(user) {
  // Deliberately does NOT embed verificationStatus in the token: status can
  // change (an admin approves/rejects) after the token is issued, and a
  // signed-but-stale claim would let a since-rejected user's existing
  // session keep claiming "verified" until it expires. Anything that needs
  // the live status re-reads it from the DB (see GET /auth/me below).
  return jwt.sign(
    { sub: user.id, email: user.email, name: user.name, role: "user" },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "12h" }
  );
}

// Create a new student/staff account. Requires basic info plus a selfie and
// ID document for verification (spec sections 13-14) and explicit consent
// (section 18). The account is created with verificationStatus = "pending"
// (section 15) — nothing here claims the identity has actually been
// verified; that only happens through the admin-only endpoints below.
router.post("/auth/register", (req, res) => {
  const { name, email, phone, password, selfieDataUrl, idDocumentDataUrl, consent } = req.body || {};

  if (!name || !email || !phone || !password) {
    return res.status(400).json({ error: "name, email, phone and password are required." });
  }
  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: "Please provide a valid email address." });
  }
  if (!PHONE_RE.test(phone)) {
    return res.status(400).json({ error: "Please provide a valid phone number." });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }
  if (!selfieDataUrl) {
    return res.status(400).json({ error: "A selfie photo is required to verify your account." });
  }
  if (!idDocumentDataUrl) {
    return res.status(400).json({ error: "A photo of your identification document is required to verify your account." });
  }
  if (consent !== true) {
    return res.status(400).json({ error: "You must consent to identity verification before submitting registration." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    return res.status(409).json({ error: "An account with that email already exists." });
  }

  let selfieFilename = null;
  let idDocumentFilename = null;
  try {
    selfieFilename = saveVerificationDocument(selfieDataUrl);
    idDocumentFilename = saveVerificationDocument(idDocumentDataUrl);
  } catch (e) {
    // Clean up whichever file did get written before the error.
    deleteVerificationDocument(selfieFilename);
    deleteVerificationDocument(idDocumentFilename);
    return res.status(400).json({ error: e.message });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  const now = new Date().toISOString();

  let id;
  try {
    ({ lastInsertRowid: id } = db
      .prepare(
        `INSERT INTO users
           (name, email, phone, password_hash, verification_status, selfie_path, id_document_path,
            consent_given, consent_at, verification_submitted_at)
         VALUES (?, ?, ?, ?, 'pending', ?, ?, 1, ?, ?)`
      )
      .run(name, email, phone, passwordHash, selfieFilename, idDocumentFilename, now, now));
  } catch (e) {
    // e.g. a race on the email-uniqueness check above — don't leave orphaned files.
    deleteVerificationDocument(selfieFilename);
    deleteVerificationDocument(idDocumentFilename);
    return res.status(409).json({ error: "An account with that email already exists." });
  }

  const token = signUserToken({ id, name, email });
  const publicUser = getPublicUserById(id);
  res.status(201).json({ token, ...publicUser });
});

// Log in to an existing account.
router.post("/auth/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "email and password are required." });

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const token = signUserToken(user);
  const publicUser = getPublicUserById(user.id);
  res.json({ token, ...publicUser });
});

// Lets the frontend confirm a stored token is still valid on load/refresh,
// and re-reads the live verification status (rather than trusting the JWT
// or anything the client sends) so an approval/rejection that happened
// after login shows up without waiting for the token to expire.
router.get("/auth/me", requireUser, (req, res) => {
  const publicUser = getPublicUserById(req.user.sub);
  if (!publicUser) return res.status(401).json({ error: "Account no longer exists." });
  res.json(publicUser);
});

export default router;
