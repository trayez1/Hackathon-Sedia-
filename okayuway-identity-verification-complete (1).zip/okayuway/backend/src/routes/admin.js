import { Router } from "express";
import fs from "node:fs";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db, resetToSeed } from "../db/index.js";
import { applyVerification, getAdminStats, getHeatmapData } from "../services/reportsService.js";
import {
  getPendingUsers, getAdminUserDetail, getVerificationDocumentPath,
  approveVerification, rejectVerification, purgeExpiredVerificationDocuments,
} from "../services/usersService.js";
import { requireAdmin } from "../middleware/auth.js";
import { broadcast } from "../services/eventBus.js";

const router = Router();

const VALID_STATUSES = new Set(["pending", "reviewing", "verified", "rejected", "resolved"]);

router.post("/admin/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "email and password are required." });

  const admin = db.prepare("SELECT * FROM admin_users WHERE email = ?").get(email);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const token = jwt.sign(
    { sub: admin.id, email: admin.email, name: admin.name, role: "admin" },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "12h" }
  );
  res.json({ token, name: admin.name, email: admin.email });
});

router.post("/admin/reports/:id/status", requireAdmin, (req, res) => {
  const { status } = req.body || {};
  if (!VALID_STATUSES.has(status)) {
    return res.status(400).json({ error: `status must be one of: ${[...VALID_STATUSES].join(", ")}` });
  }
  const report = applyVerification(req.params.id, status);
  if (!report) return res.status(404).json({ error: "Report not found." });
  broadcast({ type: "report_updated", reportId: report.id });
  res.json(report);
});

router.get("/admin/stats", (req, res) => {
  res.json(getAdminStats());
});

router.get("/admin/heatmap", (req, res) => {
  res.json(getHeatmapData());
});

router.post("/admin/reset", requireAdmin, (req, res) => {
  resetToSeed();
  broadcast({ type: "full_refresh" });
  res.json({ ok: true });
});

// ---------------------------------------------------------------------------
// User identity verification (spec sections 15-19). All routes here require
// an admin session — a normal user token has role "user" and requireAdmin
// rejects it (see middleware/auth.js).
// ---------------------------------------------------------------------------

// Accounts currently awaiting review. Only metadata — never document bytes
// (see usersService.rowToAdminUser / rowToPublicUser).
router.get("/admin/users/pending", requireAdmin, (req, res) => {
  res.json(getPendingUsers());
});

router.get("/admin/users/:id", requireAdmin, (req, res) => {
  const user = getAdminUserDetail(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json(user);
});

// Streams a submitted selfie or ID document. Never mounted as a static
// directory (see services/secureDocumentStorage.js) — this is the only
// way to read one back, and it's gated behind requireAdmin. Not exposed to
// normal users under any route.
router.get("/admin/users/:id/document/:kind", requireAdmin, (req, res) => {
  const { kind } = req.params;
  if (kind !== "selfie" && kind !== "id") {
    return res.status(400).json({ error: "kind must be 'selfie' or 'id'." });
  }
  const resolved = getVerificationDocumentPath(req.params.id, kind);
  if (!resolved) return res.status(404).json({ error: "Document not found." });

  res.setHeader("Content-Type", resolved.contentType);
  // Verification documents must never be cached by shared/browser caches.
  res.setHeader("Cache-Control", "no-store, private");
  fs.createReadStream(resolved.absolutePath).pipe(res);
});

router.post("/admin/users/:id/verify", requireAdmin, (req, res) => {
  const user = approveVerification(req.params.id, req.admin.name);
  if (!user) return res.status(404).json({ error: "User not found." });
  broadcast({ type: "user_verification_updated", userId: user.id });
  res.json(user);
});

router.post("/admin/users/:id/reject", requireAdmin, (req, res) => {
  const user = rejectVerification(req.params.id, req.admin.name);
  if (!user) return res.status(404).json({ error: "User not found." });
  broadcast({ type: "user_verification_updated", userId: user.id });
  res.json(user);
});

// Retention/minimization (spec section 19): deletes the on-disk selfie/ID
// files for users whose verification was decided more than
// VERIFICATION_DOCUMENT_RETENTION_DAYS ago. Admin-triggered because this
// repo has no job scheduler — wire this up to a cron in production instead
// of relying on someone clicking it (see backend/README.md).
router.post("/admin/verification/cleanup", requireAdmin, (req, res) => {
  const purged = purgeExpiredVerificationDocuments();
  res.json({ purged });
});

export default router;
