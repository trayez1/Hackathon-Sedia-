import { Router } from "express";
import {
  getReports, getReportsForLocation, createReport, confirmReport, disputeReport,
} from "../services/reportsService.js";
import { runAIAnalysis } from "../services/aiAnalysis.js";
import { savePhotoFromDataUrl } from "../services/photoStorage.js";
import { broadcast } from "../services/eventBus.js";
import { requireUser } from "../middleware/auth.js";

const router = Router();

router.get("/reports", (req, res) => {
  res.json(getReports());
});

router.get("/locations/:locationId/reports", (req, res) => {
  res.json(getReportsForLocation(req.params.locationId));
});

// Requires a logged-in account (spec section 20-21: reports need to be
// accountable to a real account to cut down on spam/fake reports, without
// blocking legitimate reporting). The reporting user's id always comes
// from the verified JWT (req.user.sub), never from the request body — the
// frontend has no way to submit a report "as" a different account.
router.post("/reports", requireUser, (req, res) => {
  const { locationId, featureId, type, description, photoDataUrl, aiAnalysis } = req.body || {};
  if (!locationId || !type || !description) {
    return res.status(400).json({ error: "locationId, type, and description are required." });
  }
  if (!photoDataUrl) {
    return res.status(400).json({ error: "Photo evidence is required to submit a report." });
  }

  let photoUrl = null;
  try {
    photoUrl = savePhotoFromDataUrl(photoDataUrl);
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }

  const report = createReport({ locationId, featureId, type, description, photoUrl, aiAnalysis, userId: req.user.sub });
  broadcast({ type: "report_created", reportId: report.id });
  res.status(201).json(report);
});

router.post("/reports/:id/confirm", (req, res) => {
  const report = confirmReport(req.params.id);
  if (!report) return res.status(404).json({ error: "Report not found." });
  broadcast({ type: "report_updated", reportId: report.id });
  res.json(report);
});

router.post("/reports/:id/dispute", (req, res) => {
  const report = disputeReport(req.params.id);
  if (!report) return res.status(404).json({ error: "Report not found." });
  broadcast({ type: "report_updated", reportId: report.id });
  res.json(report);
});

router.post("/ai-analysis", async (req, res) => {
  const { obstacleType, hasPhoto } = req.body || {};
  const result = await runAIAnalysis({ obstacleType, hasPhoto });
  res.json(result);
});

export default router;
