import { useState } from "react";
import { userLogin, userRegister } from "../services/store.js";

const MAX_PHOTO_BYTES = 8 * 1024 * 1024;

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Please upload an image file."));
      return;
    }
    if (file.size > MAX_PHOTO_BYTES) {
      reject(new Error("Image is too large (max 8MB)."));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read that file. Please try again."));
    reader.readAsDataURL(file);
  });
}

const EMPTY_FORM = { name: "", email: "", phone: "", password: "" };

// Standalone user sign-in / sign-up screen. Kept separate from
// pages/admin/AdminLogin.jsx: this is for regular students/staff and posts
// to /api/auth/*, while AdminLogin.jsx posts to /api/admin/login and is only
// ever reachable from the /admin route.
//
// Registration is a 3-step flow (spec sections 13-18): basic info, then a
// selfie + ID document photo, then explicit consent before the account is
// created. Sign-in stays a single step.
export default function UserLogin({ onSuccess }) {
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [step, setStep] = useState(1); // 1: basic info, 2: photos, 3: consent — register only
  const [form, setForm] = useState(EMPTY_FORM);
  const [selfieDataUrl, setSelfieDataUrl] = useState(null);
  const [idDocumentDataUrl, setIdDocumentDataUrl] = useState(null);
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const isRegister = mode === "register";

  function switchMode(next) {
    setMode(next);
    setStep(1);
    setForm(EMPTY_FORM);
    setSelfieDataUrl(null);
    setIdDocumentDataUrl(null);
    setConsent(false);
    setError("");
  }

  function validateStep1() {
    if (!form.name.trim()) return "Please enter your name.";
    if (!form.email.trim()) return "Please enter your email.";
    if (!form.phone.trim()) return "Please enter your phone number.";
    if (form.password.length < 8) return "Password must be at least 8 characters.";
    return "";
  }

  function goToStep2(e) {
    e.preventDefault();
    const msg = validateStep1();
    if (msg) { setError(msg); return; }
    setError("");
    setStep(2);
  }

  function goToStep3(e) {
    e.preventDefault();
    if (!selfieDataUrl) { setError("Please add a selfie photo."); return; }
    if (!idDocumentDataUrl) { setError("Please add a photo of your identification document."); return; }
    setError("");
    setStep(3);
  }

  async function handlePhotoInput(e, setter) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setter(dataUrl);
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleLogin(e) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await userLogin(form.email, form.password);
      onSuccess?.();
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleRegisterSubmit(e) {
    e.preventDefault();
    if (!consent) { setError("You must consent to identity verification before submitting."); return; }
    setSubmitting(true);
    setError("");
    try {
      await userRegister({
        name: form.name,
        email: form.email,
        phone: form.phone,
        password: form.password,
        selfieDataUrl,
        idDocumentDataUrl,
        consent,
      });
      onSuccess?.();
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-sm rounded-2xl bg-white ring-1 ring-ink-900/10 p-6 shadow-sm">
        <h1 className="text-lg font-bold text-ink-900">
          {isRegister ? "Create your account" : "Sign in"}
        </h1>
        <p className="text-sm text-ink-900/60 mt-1 mb-5">
          {isRegister
            ? "Sign up to save reports and track your accessibility routes."
            : "Welcome back to okayUway."}
        </p>

        {isRegister && <StepIndicator step={step} />}

        {!isRegister && (
          <form onSubmit={handleLogin} noValidate>
            <Field label="Email" htmlFor="user-email">
              <input
                id="user-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm"
                placeholder="you@mmu.edu.my"
                autoComplete="username"
                required
              />
            </Field>
            <Field label="Password" htmlFor="user-password">
              <input
                id="user-password"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm"
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
            </Field>

            {error && <p className="text-xs text-red-600 mb-3" role="alert">{error}</p>}

            <SubmitButton submitting={submitting} label="Sign in" busyLabel="Signing in…" />
          </form>
        )}

        {isRegister && step === 1 && (
          <form onSubmit={goToStep2} noValidate>
            <Field label="Name" htmlFor="user-name">
              <input
                id="user-name"
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm"
                placeholder="Your full name"
                autoComplete="name"
                required
              />
            </Field>
            <Field label="Email" htmlFor="user-email">
              <input
                id="user-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm"
                placeholder="you@mmu.edu.my"
                autoComplete="username"
                required
              />
            </Field>
            <Field label="Phone number" htmlFor="user-phone">
              <input
                id="user-phone"
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm"
                placeholder="+60 12-345 6789"
                autoComplete="tel"
                required
              />
            </Field>
            <Field label="Password" htmlFor="user-password">
              <input
                id="user-password"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="focus-ring w-full rounded-xl ring-1 ring-ink-900/15 px-4 py-2.5 text-sm"
                placeholder="At least 8 characters"
                autoComplete="new-password"
                minLength={8}
                required
              />
            </Field>

            {error && <p className="text-xs text-red-600 mb-3" role="alert">{error}</p>}

            <SubmitButton label="Continue" />
          </form>
        )}

        {isRegister && step === 2 && (
          <form onSubmit={goToStep3} noValidate>
            <p className="text-xs text-ink-900/60 mb-4">
              To keep reports accountable, we need a quick selfie and a photo of an
              ID document. These are stored securely and only reviewed by campus
              administrators for verification.
            </p>

            <PhotoField
              label="Selfie"
              hint="A clear photo of your face."
              dataUrl={selfieDataUrl}
              onChange={(e) => handlePhotoInput(e, setSelfieDataUrl)}
              onClear={() => setSelfieDataUrl(null)}
              capture="user"
            />

            <PhotoField
              label="Identification document"
              hint="Student/staff ID, MyKad, or passport."
              dataUrl={idDocumentDataUrl}
              onChange={(e) => handlePhotoInput(e, setIdDocumentDataUrl)}
              onClear={() => setIdDocumentDataUrl(null)}
            />

            {error && <p className="text-xs text-red-600 mb-3" role="alert">{error}</p>}

            <div className="flex gap-2">
              <BackButton onClick={() => { setStep(1); setError(""); }} />
              <SubmitButton label="Continue" />
            </div>
          </form>
        )}

        {isRegister && step === 3 && (
          <form onSubmit={handleRegisterSubmit} noValidate>
            <div className="rounded-xl bg-ink-900/5 p-4 mb-4">
              <p className="text-xs text-ink-900/70 leading-relaxed">
                By submitting, you consent to okayUway collecting your selfie and ID
                document photo for the sole purpose of verifying your identity as a
                genuine student or staff member. Documents are reviewed by campus
                administrators, stored securely, and are not shared publicly. This
                is a document-submission check, not formal identity proofing.
              </p>
            </div>

            <label className="flex items-start gap-2.5 mb-4 cursor-pointer">
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="focus-ring mt-0.5 w-4 h-4 rounded ring-1 ring-ink-900/15"
                required
              />
              <span className="text-sm text-ink-900/80">
                I consent to identity verification as described above.
              </span>
            </label>

            {error && <p className="text-xs text-red-600 mb-3" role="alert">{error}</p>}

            <div className="flex gap-2">
              <BackButton onClick={() => { setStep(2); setError(""); }} />
              <SubmitButton submitting={submitting} label="Create account" busyLabel="Creating account…" />
            </div>
          </form>
        )}

        <p className="text-xs text-ink-900/60 mt-4 text-center">
          {isRegister ? "Already have an account?" : "New to okayUway?"}{" "}
          <button
            type="button"
            onClick={() => switchMode(isRegister ? "login" : "register")}
            className="focus-ring font-semibold text-brand-600 hover:underline"
          >
            {isRegister ? "Sign in" : "Create one"}
          </button>
        </p>
      </div>
    </div>
  );
}

function StepIndicator({ step }) {
  const labels = ["Basic info", "Verify identity", "Consent"];
  return (
    <div className="flex items-center gap-2 mb-5" aria-label={`Step ${step} of 3`}>
      {labels.map((label, i) => {
        const n = i + 1;
        const active = n === step;
        const done = n < step;
        return (
          <div key={label} className="flex items-center gap-2 flex-1">
            <span
              className={`shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold ${
                done ? "bg-brand-600 text-white" : active ? "bg-brand-100 text-brand-700 ring-1 ring-brand-300" : "bg-ink-900/5 text-ink-900/40"
              }`}
            >
              {done ? "✓" : n}
            </span>
            {n < 3 && <span className={`h-0.5 flex-1 ${done ? "bg-brand-600" : "bg-ink-900/10"}`} />}
          </div>
        );
      })}
    </div>
  );
}

function Field({ label, htmlFor, children }) {
  return (
    <div className="mb-3">
      <label htmlFor={htmlFor} className="block text-sm font-medium mb-1">{label}</label>
      {children}
    </div>
  );
}

function PhotoField({ label, hint, dataUrl, onChange, onClear, capture }) {
  return (
    <div className="mb-4">
      <label className="block text-sm font-semibold text-ink-900/70 mb-1.5">{label}</label>
      <p className="text-[11px] text-ink-900/45 mb-1.5">{hint}</p>
      {dataUrl ? (
        <div className="flex items-center gap-3">
          <img src={dataUrl} alt={`${label} preview`} className="w-16 h-16 object-cover rounded-lg ring-1 ring-ink-900/10" />
          <button
            type="button"
            onClick={onClear}
            className="focus-ring rounded-lg bg-ink-900/5 hover:bg-ink-900/10 text-ink-900/70 text-xs font-medium px-3 py-1.5"
          >
            Retake
          </button>
        </div>
      ) : (
        <input
          type="file"
          accept="image/*"
          capture={capture}
          onChange={onChange}
          className="focus-ring block w-full text-sm text-ink-900/70 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:text-brand-700 file:px-3 file:py-2 file:font-medium"
        />
      )}
    </div>
  );
}

function SubmitButton({ submitting, label, busyLabel }) {
  return (
    <button
      type="submit"
      disabled={submitting}
      className="focus-ring flex-1 w-full rounded-xl bg-brand-600 hover:bg-brand-600/90 disabled:opacity-60 text-white font-semibold px-4 py-3 text-sm"
    >
      {submitting ? (busyLabel || label) : label}
    </button>
  );
}

function BackButton({ onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="focus-ring rounded-xl ring-1 ring-ink-900/15 px-4 py-3 text-sm font-medium hover:bg-ink-900/5"
    >
      Back
    </button>
  );
}
