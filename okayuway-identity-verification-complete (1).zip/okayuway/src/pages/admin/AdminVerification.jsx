import { useEffect, useState } from "react";
import {
  adminListPendingUsers, adminGetVerificationDocumentUrl,
  adminApproveUser, adminRejectUser,
} from "../../services/store.js";
import { timeAgo } from "../../utils/time.js";

// Admin review screen for pending identity verification (spec sections
// 15-19). Pending users don't come through the bootstrap/SSE cache like
// reports do, so this component fetches and refetches its own list rather
// than reading from services/store.js's synchronous getters.
export default function AdminVerification() {
  const [users, setUsers] = useState(null); // null = loading
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null); // user id currently expanded
  const [acting, setActing] = useState(null); // user id currently being approved/rejected

  async function refresh() {
    try {
      const data = await adminListPendingUsers();
      setUsers(data);
      setError("");
    } catch (e) {
      setError(e.message || "Could not load pending verifications.");
    }
  }

  useEffect(() => { refresh(); }, []);

  async function handleDecision(userId, decision) {
    setActing(userId);
    try {
      if (decision === "verify") await adminApproveUser(userId);
      else await adminRejectUser(userId);
      setSelected(null);
      await refresh();
    } catch (e) {
      setError(e.message || "Could not update this account. Please try again.");
    } finally {
      setActing(null);
    }
  }

  if (error) {
    return (
      <div className="rounded-2xl bg-red-50 ring-1 ring-red-200 p-5 text-sm text-red-700">
        {error}
        <button onClick={refresh} className="focus-ring block mt-2 font-semibold underline">Try again</button>
      </div>
    );
  }

  if (users === null) {
    return <p className="text-sm text-ink-900/50">Loading pending verifications…</p>;
  }

  if (users.length === 0) {
    return (
      <div className="rounded-2xl bg-white ring-1 ring-ink-900/10 p-6 text-center">
        <p className="text-2xl mb-2">✓</p>
        <p className="text-sm text-ink-900/60">No accounts are waiting on verification.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {users.map((u) => (
        <PendingUserCard
          key={u.id}
          user={u}
          expanded={selected === u.id}
          onToggle={() => setSelected(selected === u.id ? null : u.id)}
          onDecision={(decision) => handleDecision(u.id, decision)}
          acting={acting === u.id}
        />
      ))}
    </div>
  );
}

function PendingUserCard({ user, expanded, onToggle, onDecision, acting }) {
  return (
    <div className="rounded-2xl ring-1 ring-ink-900/10 bg-white overflow-hidden">
      <button
        onClick={onToggle}
        className="focus-ring w-full flex items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-ink-900/5"
      >
        <div>
          <p className="font-semibold text-sm text-ink-900">{user.name}</p>
          <p className="text-xs text-ink-900/50">{user.email} · {user.phone}</p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <span className="text-xs text-ink-900/40">
            Submitted {timeAgo(user.verificationSubmittedAt)}
          </span>
          <span className="text-ink-900/40 text-xs">{expanded ? "▲" : "▼"}</span>
        </div>
      </button>

      {expanded && (
        <div className="border-t border-ink-900/10 px-4 py-4">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <DocumentPreview userId={user.id} kind="selfie" label="Selfie" available={user.hasSelfie} />
            <DocumentPreview userId={user.id} kind="id" label="ID document" available={user.hasIdDocument} />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onDecision("verify")}
              disabled={acting}
              className="focus-ring rounded-lg bg-brand-50 hover:bg-brand-100 disabled:opacity-60 text-brand-700 text-sm font-semibold px-4 py-2 ring-1 ring-brand-200"
            >
              {acting ? "Working…" : "✓ Verify account"}
            </button>
            <button
              onClick={() => onDecision("reject")}
              disabled={acting}
              className="focus-ring rounded-lg bg-red-50 hover:bg-red-100 disabled:opacity-60 text-red-700 text-sm font-semibold px-4 py-2 ring-1 ring-red-200"
            >
              {acting ? "Working…" : "✕ Reject"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Fetches the document as an authed blob URL only once the card is
// expanded (not for every pending user up front), and revokes it on
// unmount/collapse so we don't leak object URLs while flipping through
// several review cards.
function DocumentPreview({ userId, kind, label, available }) {
  const [url, setUrl] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    let objectUrl = null;
    if (available) {
      adminGetVerificationDocumentUrl(userId, kind)
        .then((u) => { if (!cancelled) { objectUrl = u; setUrl(u); } })
        .catch((e) => { if (!cancelled) setError(e.message || "Could not load document."); });
    }
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [userId, kind, available]);

  return (
    <div>
      <p className="text-xs font-semibold text-ink-900/60 mb-1.5">{label}</p>
      <div className="rounded-xl bg-ink-900/5 ring-1 ring-ink-900/10 aspect-square flex items-center justify-center overflow-hidden">
        {!available ? (
          <span className="text-xs text-ink-900/40">Not submitted</span>
        ) : error ? (
          <span className="text-xs text-red-600 px-2 text-center">{error}</span>
        ) : url ? (
          <img src={url} alt={`${label} submitted for verification`} className="w-full h-full object-cover" />
        ) : (
          <span className="text-xs text-ink-900/40">Loading…</span>
        )}
      </div>
    </div>
  );
}
